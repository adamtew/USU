#include <iostream>
#include <array>
#include <fstream>
#include "Game.h"

using namespace std;

Game game;

int main() {
	game.play();
}
