50
	 ____________________
	|XXX XXXX XX XXXXXXXX|
	|XXXXXXXXXXXXXXXXXXXX|
	| XXXXXXX XX XXXXXXXX|
	|XXX XXXXXXXX XXXXXXX|
	|XXXX XXXXXXXX XXXXX |
	|XXXXXXXXXXXXXXXXX XX|
	|XXX XXXXX   XX XXXXX|
	|XXXXXXXX XX XXXXXX X|
	|XX XXXXXXXXXXXXXXXXX|
	|XXXXXXXXXXX XXXXXXXX|
	|XXXXXXXXX XXXXX  XXX|
	|X XXXXXXXXX XXXXXXXX|
	|XXXXXX XXXXXXXXXXXX |
	|XXX XXXXXXXXXXXXXXXX|
	|X XXXXXXXXXXXXXXX XX|
	|XXXXX  XX  XXXXX XXX|
	|XXXXXX XX XXXXXXX XX|
	|XXXXXXXXXXXXX X XXXX|
	|XXXXXXXXXXXXX  XX XX|
	|XX   XXXXXXXXXXXXXXX|
	 ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
100
	 ____________________
	|XXX XXXX XX XXXXXXXX|
	|XXXXXXXXX XXXX XXXXX|
	| XX XXXX XX XXXXXXXX|
	|XXX XXXXXXXX X  X XX|
	|XXX   X XXXXX XXXXX |
	|X XXXX XX XXXXXXX XX|
	|XXX XXXXX   XX XXX  |
	|XXXX  XX XX XX XXX X|
	|XX   XXXXXXXXX XXXXX|
	|X  XXXXXXXX XXXXXXXX|
	|XXXXXX XX XXXX   XXX|
	|X XXXXX XXX XXXXXXXX|
	| XXXXX XXXXXXXX  X  |
	|XX  XXXXX XXXXXXXXXX|
	|  X XXX XXXXXXXXX XX|
	|XXXXX  XX   XXXX XX |
	|XXXXXX X  XXX XXX XX|
	|XXXXXXXXXXXXX   XXXX|
	|XXXXXXXXXXX X  XX  X|
	|X    XXXXXXXXXXXXXXX|
	 ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
150
	 ____________________
	| XX X XX XX X XXX XX|
	|XXXXXXXX  XX X XX XX|
	| XX XXXX XX XXXXXXXX|
	|XXX XXXXXXXX X  X XX|
	|XXX   X XXX X X XXX |
	|X XX X XX XXXXXXX   |
	|XXX XXX X   XX XXX  |
	|XXXX  XX X  XX XXX X|
	|XX   X  XXX XX XXXX |
	|X  XXXX  XX XXXXXXXX|
	|XXXXXX XX XXXX   XXX|
	|  XXXXX XX  XXXXXXXX|
	| XXXXX XXXXXXXX  X  |
	|XX  XXXXX XXXX XXXXX|
	|  X XX  XXXX XXXX XX|
	| XXXX  XX   XX X    |
	|XX XXX X  XXX XXX XX|
	|XXXXX XXXXXXX   XXXX|
	|XXX XXXXXXX    X   X|
	|X    XXX XXXXXXXXXXX|
	 ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
200
	 ____________________
	|  X X XX XX X XX   X|
	|XXXXXXX   XX X XX XX|
	| XX XXXX XX XXXXXXXX|
	| XX  XXXXXXX X  X XX|
	|XXX   X XXX X X XXX |
	|X XX X  X XXXXXX    |
	|XX  XXX     XX XXX  |
	|XXXX  XX X  XX XXX X|
	|XX   X  XXX  X XXXX |
	|X    X   XX XXXXXXX |
	|XXXXXX XX XX X   XXX|
	|  XX XX XX  XXX  XXX|
	| XXXXX X X XX X  X  |
	|X   XX  X  XXX XXXXX|
	|  X XX  XXXX X  X XX|
	| X XX  XX   XX X    |
	|XX X X X  XXX  XX XX|
	|XXXXX XX X XX   XXXX|
	|XXX  XXXXXX        X|
	|X    X X XXXXX XXXXX|
	 ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
250
	 ____________________
	|  X X X  XX X  X   X|
	|XXXXXXX   XX X XX XX|
	| XX X XX  X XXXXXXXX|
	| XX   XXXXX  X  X XX|
	|XX    X XXX   X XXX |
	|X XX X  X XXXXXX    |
	|XX  XXX      X XXX  |
	|XXXX   X X  XX XXX X|
	|XX   X  XXX    XXXX |
	|X        XX XX  XXX |
	|XXXXXX X  XX X   XXX|
	|  XX  X  X  X X  XXX|
	| XXXXX X X XX X  X  |
	|X   XX     XXX  XXXX|
	|  X XX  XX X X  X XX|
	| X  X  XX   XX X    |
	|XX X X X   XX  XX XX|
	|XXXXX XX X XX   XX X|
	|XXX   XXXXX        X|
	|X    X X  XXXX XXXXX|
	 ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
300
	 ____________________
	|  X X X  X     X   X|
	|XXXXXXX   XX X XX X |
	| XX X XX  X XXXXXXXX|
	| XX   XXXXX  X  X X |
	|XX    X XXX   X XXX |
	|  XX    X XXX XX    |
	|XX  XXX      X X X  |
	|XXXX   X X  XX XXX X|
	|XX   X   XX    XX X |
	|X        XX XX  XXX |
	|XXXXX  X  XX X   XXX|
	|  XX  X       X  XXX|
	| XXXXX X X XX X  X  |
	|X   XX     XXX  XXXX|
	|  X XX  XX X X    XX|
	| X     XX   XX X    |
	|XX X   X   X   X  XX|
	|XXXXX XX X XX   XX X|
	|XXX   XXXXX        X|
	|X          XXX XXXXX|
	 ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
350
	 ____________________
	|  X X X  X     X   X|
	|XXXXXXX   XX X XX X |
	| XX X XX  X  XX XXXX|
	| XX   XXXXX     X X |
	|XX    X  XX   X XXX |
	|   X    X XXX XX    |
	|XX   XX      X X X  |
	|XXXX   X X  XX  XX X|
	|XX   X   XX     X X |
	|X        XX X   XXX |
	|X XXX  X  X  X   XXX|
	|  XX  X       X  XXX|
	| X XXX   X XX X     |
	|X   XX     XXX  XXXX|
	|  X XX  XX X      XX|
	| X     XX      X    |
	|XX X   X   X   X  XX|
	|XXX X XX X X    XX  |
	|XXX   XXXX         X|
	|X          XXX XXXXX|
	 ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
400
	 ____________________
	|    X X  X     X   X|
	|X XXXX    XX X XX X |
	| XX X XX  X  XX XXXX|
	| XX   XXXXX     X X |
	|X     X  X      XXX |
	|   X      XXX XX    |
	|XX    X      X X X  |
	|XXXX   X X  X   XX X|
	|XX   X   XX     X   |
	|X        XX X   X   |
	|X XXX  X     X   XXX|
	|  XX  X       X  XXX|
	|    XX     X  X     |
	|X    X     XXX  XXXX|
	|    XX  XX X      XX|
	|       X       X    |
	|XX X   X   X   X  XX|
	|XXX X XX X X    XX  |
	|XXX   XXXX         X|
	|X          XXX  XXXX|
	 ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

It took 424 iterations to percolate
	 ____________________
	|    X X  X     X   X|
	|X XXXX    XX X X  X |
	| XX   X   X  XX XXXX|
	| XX   XX XX     X X |
	|X     X  X      XXX |
	|   X      XXX XX    |
	|XX    X      X X X  |
	|XXXX   X X  X   XX X|
	|XX   X   XX     X   |
	|X        XX X   X   |
	|X XXX  X     X   XXX|
	|  XX  X       X  XXX|
	|    XX     X  X     |
	|X    X     XXX  X XX|
	|    XX  XX X      XX|
	|       X       X    |
	|XX X   X   X   X  XX|
	|XXX X  X X X    X   |
	|XXX   XXXX         X|
	|X          XXX  XXXX|
	 ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
