first = "Adam"
last = "Tew"
br = "\n"
info = "Student at Utah State University"
print first, last, br, info
import sys
print sys.version

