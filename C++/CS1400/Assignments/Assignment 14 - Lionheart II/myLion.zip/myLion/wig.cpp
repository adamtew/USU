#include "wig.h"
#include <cmath>
#include <iostream>

struct Loc{
	int x, y;
	Loc(int ix = 0, int iy = 0){
		x = ix;
		y = iy;
	}
};

Loc evaluateSpace(int minR, int maxR, int minC, int maxC, SitRep sitrep){
	Loc loc;
	cout << "\nminC\n " << minC << endl;
	if (minC == 0){

		for (int i = minR + 2; i <= maxR; i++){
			for (int j = minC; j <= maxC; j++){
				if (sitrep.thing[i][j].what == space){
					loc.x = i;
					loc.y = j;
					return loc;
				}
			}
		}

	}else if(minC == 24){
		for (int i = maxR - 3; i >= minR; i--){
			for (int j = maxC; j >= minC; j--){
				if (sitrep.thing[i][j].what == space){
					loc.x = i;
					loc.y = j;
					return loc;
				}
			}
		}
	}
}

void wig::Place(int minR, int maxR, int minC, int maxC, SitRep sitrep){
	Loc loc;
	Dir myDir;
	bool done = false;
	//cout << "\nminR " << minR << "\nmaxR " << maxR << "\nminC " << minC << "\nmaxC " << maxC << endl;
	
	loc = evaluateSpace(minR, maxR, minC, maxC, sitrep);

	int rdist = ROWS / 2 - loc.x;
	int cdist = COLS / 2 - loc.y;

	if (abs(rdist) < abs(cdist)){
		if (cdist>0)myDir = rt;
		else myDir = lt;
	}	else{
		if (rdist>0)myDir = up;
		else myDir = dn;
	}

	r = loc.x;
	c = loc.y;
	dir = myDir;

}


// tell someone what you want to do
Action wig::Recommendation(SitRep sitrep){
	
	// this code is provided as an example only
	// use at your own risk
	Action a; 

	// first, try to attack in front of you
	int tr=r,tc=c;
	switch(dir){
	case up: tr--; break;
	case dn: tr++; break;
	case rt: tc++; break;
	case lt: tc--; break;
	case none: break;
	}
	if(tr>=0&&tr<ROWS&&tc>=0&&tc<COLS){
		if(sitrep.thing[tr][tc].what==unit){
			if(sitrep.thing[tr][tc].tla!=tla){
				a.action=attack;
				a.ar=tr;
				a.ac=tc;
				return a;
			}
		}
	}	
	// there is not an enemy in front of me
	// so head to the nearest enemy
	if(dir==sitrep.nearestEnemy.dirFor){
		a.action=fwd;
		a.maxDist=1;
		if(rank==knight||rank==crown)a.maxDist=HORSESPEED;
		return a;
	} else {
		a.action=turn;
		a.dir=sitrep.nearestEnemy.dirFor;
		return a;
	}
	a.action=nothing;
	return a;
	
}
